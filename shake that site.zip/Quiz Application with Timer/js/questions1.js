let questions1 = [
    {
    numb: 1,
    question: "Que signifient les trois lettres de l’acronyme « COP15",
    answer: "conference des parties",
    options: [
      "coalition opposée a la pollution",
      "conference des parties",
      "conferences de paris",
      "organisation pour la protection climatique"
    ]
  },
    {
    numb: 2,
    question: "Quel pays a le plus d'émissions de gaz à effet de serre par habitant ?",
    answer: "L'Australie",
    options: [
      "Les États-Unis",
      "La Norvège",
      "Le Japon",
      "L'Australie"
    ]
  },
    {
    numb: 3,
    question: "Si toute l’énergie que je consommais était d’origine humaine, combien me faudrait-il d’humains à mon service ?Cette question est requise",
    answer: "200",
    options: [
      "200",
      "2",
      "2000",
      "20"
    ]
  },
    {
    numb: 4,
    question: "Où auront lieu les premiers impacts majeurs du changement climatique ?Cette question est requise",
    answer: "Sur les latitudes nord",
    options: [
      "Sur les tropiques",
      "Sur l'équateur",
      "La distribution est égale",
      "Sur les latitudes nord"
    ]
  },
    {
    numb: 5,
    question: "Par tes actions, la planète a pris 2 °C depuis le début du CarboQuiz. Le pire scenario du GIEC prévoit d’ici 2100 une augmentation de :",
    answer: "12°C",
    options: [
      "12°C",
      "8°C",
      "2°C",
      "5°C"
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];