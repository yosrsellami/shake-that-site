// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "En matière d alimentation, quelle solution est la plus efficace",
    answer: "Manger moins de viande",
    options: [
      "Mettre en place une culture du riz plus efficiente et durable",
      "Manger moins de viande",
      "Installer des foyers de cuissondans les pays en développement",
      "Arrêtez le thon rouge"
    ]
  },
    {
    numb: 2,
    question: "Quelle action diminuerait le plus nos émissions de gaz à effet de serre ?Cette question est requise",
    answer: "Fermer les centrales à énergie carbonée",
    options: [
      "Faire pousser nos légumes",
      "Arrêter la déforestation",
      "Retirer les véhicules à essence",
      "Fermer les centrales à énergie carbonée"
    ]
  },
    {
    numb: 3,
    question: "En matière de transport, quelle action aurait le plus d’impact?",
    answer: "Améliorer l’efficience des avions",
    options: [
      "Améliorer l’efficience des avions",
      "Développer le télétravail",
      "Construire un réseau global de trains à grande vitesse",
      "Lancer un grand plan pour favoriser les vélos taxis"
    ]
  },
    {
    numb: 4,
    question: "Quel gaz a l'effet de serre le plus puissant ?",
    answer: "Vapeur d'eau",
    options: [
      "Méthane",
      "CO2",
      "Méthane",
      "Vapeur d'eau"
    ]
  },
    {
    numb: 5,
    question: "Quelle action me permettrait de diminuer le plus mon empreinte carbone ?",
    answer: "Baisser de 1°C la consigne de chauffage",
    options: [
      "Baisser de 1°C la consigne de chauffage",
      "Reporter d’un an l’achat d’un nouveau smartphone",
      "Consommer un repas par semaine sans viande",
      "Eteindre les lumières en quittant une pièce"
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];